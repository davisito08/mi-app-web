<?php
/**
 * config.php — GravityLab
 * Configuración de base de datos y fábrica de conexión PDO.
 * ─────────────────────────────────────────────────────────
 * Ajusta DB_USER y DB_PASS con tus credenciales de MySQL.
 */

// ── Credenciales ──────────────────────────────────────────────────
define('DB_HOST',    'localhost');
define('DB_PORT',    '3306');
define('DB_NAME',    'gravitylab');
define('DB_USER',    'gravity_user');
define('DB_PASS',    'gravity_pass');
define('DB_CHARSET', 'utf8mb4');

// ── DSN ───────────────────────────────────────────────────────────
define('DB_DSN', sprintf(
    'mysql:host=%s;port=%s;dbname=%s;charset=%s',
    DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
));

// ── Opciones PDO ──────────────────────────────────────────────────
define('PDO_OPTIONS', [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
]);

/**
 * Devuelve una instancia PDO (singleton por petición).
 *
 * @return PDO
 * @throws RuntimeException  si no se puede conectar
 */
function getConnection(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        try {
            $pdo = new PDO(DB_DSN, DB_USER, DB_PASS, PDO_OPTIONS);
        } catch (PDOException $e) {
            error_log('[GravityLab] DB error: ' . $e->getMessage());
            throw new RuntimeException(
                'No se pudo conectar a la base de datos.',
                (int) $e->getCode(),
                $e
            );
        }
    }

    return $pdo;
}

// ── App general ───────────────────────────────────────────────────
define('APP_NAME',    'GravityLab');
define('APP_VERSION', '1.0.0');
define('APP_DEBUG',   true);    // ← false en producción

date_default_timezone_set('Europe/Madrid');

if (APP_DEBUG) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

/**
 * Envía una respuesta JSON y termina la ejecución.
 *
 * @param mixed $data
 * @param int   $status  Código HTTP
 */
function jsonResponse($data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
