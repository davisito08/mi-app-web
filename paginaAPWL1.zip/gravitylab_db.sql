-- MySQL dump 10.13  Distrib 8.4.8, for Linux (x86_64)
--
-- Host: localhost    Database: gravitylab
-- ------------------------------------------------------
-- Server version	8.4.8-0ubuntu0.25.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `escenas`
--

DROP TABLE IF EXISTS `escenas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `escenas` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `fondo_color` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#0f0f1a',
  `fondo_imagen` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gravedad_y` decimal(4,2) NOT NULL DEFAULT '1.00',
  `gravedad_x` decimal(4,2) NOT NULL DEFAULT '0.00',
  `es_publica` tinyint(1) NOT NULL DEFAULT '0',
  `vistas` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_publica_created` (`es_publica`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escenas`
--

LOCK TABLES `escenas` WRITE;
/*!40000 ALTER TABLE `escenas` DISABLE KEYS */;
INSERT INTO `escenas` VALUES (23,'Deriva Espacial','Un astronauta se ha soltado del cable de seguridad. No hay gravedad arriba ni abajo, solo un ligero viento solar que lo empuja hacia el vacío infinito. ¿Podrás atraparlo antes de que desaparezca?','#62a0ea','https://cdn-icons-png.flaticon.com/512/825/825062.png',0.00,0.50,0,1,'2026-05-11 09:49:18','2026-05-11 09:49:24'),(24,'Armagedón de Bolsillo','Una roca espacial cae a toda velocidad hacia la superficie. La gravedad terrestre es implacable. Intenta desviarla con el ratón antes de que toque el fondo de la pantalla.','#57e389','https://cdn-icons-png.flaticon.com/512/4165/4165974.png',3.00,0.40,0,1,'2026-05-11 09:50:37','2026-05-11 09:50:45'),(25,'Paseo por la Luna','Aquí todo pesa mucho menos. Los objetos flotan con elegancia y caen muy lentamente, como si estuvieras en el Mar de la Tranquilidad. Ideal para practicar malabares con el ratón.','#1c71d8','https://cdn.pixabay.com/photo/2014/04/02/17/07/full-moon-308007_1280.png',0.20,0.00,0,5,'2026-05-11 09:52:18','2026-05-11 09:52:38');
/*!40000 ALTER TABLE `escenas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-11 11:58:06
